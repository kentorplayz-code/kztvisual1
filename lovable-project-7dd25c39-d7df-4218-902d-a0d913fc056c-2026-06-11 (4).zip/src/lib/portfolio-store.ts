import { useEffect, useState } from "react";

export type Category = "graphic-design" | "video-editing" | "beat-making" | "script-writing";

export const CATEGORIES: { id: Category; label: string; blurb: string }[] = [
  { id: "graphic-design", label: "Graphic Design", blurb: "Posters, brand kits, social systems." },
  { id: "video-editing", label: "Video Editing", blurb: "Reels, shorts, cinematic cutdowns." },
  { id: "beat-making", label: "Beat Making", blurb: "Original beats, sound design, mixing." },
  { id: "script-writing", label: "Script Writing", blurb: "Hooks, ad scripts, short-form copy." },
];

export type PortfolioItem = {
  id: string;
  title: string;
  category: Category;
  thumbnail: string; // data url
  audio?: string;    // data url
  video?: string;    // data url
  createdAt: number;
};

const KEY = "kzt_portfolio_v1";

function read(): PortfolioItem[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(KEY);
    return raw ? (JSON.parse(raw) as PortfolioItem[]) : [];
  } catch {
    return [];
  }
}

function write(items: PortfolioItem[]) {
  localStorage.setItem(KEY, JSON.stringify(items));
  window.dispatchEvent(new Event("kzt:portfolio"));
}

export function usePortfolio() {
  const [items, setItems] = useState<PortfolioItem[]>([]);
  useEffect(() => {
    setItems(read());
    const handler = () => setItems(read());
    window.addEventListener("kzt:portfolio", handler);
    window.addEventListener("storage", handler);
    return () => {
      window.removeEventListener("kzt:portfolio", handler);
      window.removeEventListener("storage", handler);
    };
  }, []);
  return {
    items,
    add: (item: Omit<PortfolioItem, "id" | "createdAt">) => {
      const next = [{ ...item, id: crypto.randomUUID(), createdAt: Date.now() }, ...read()];
      write(next);
    },
    remove: (id: string) => write(read().filter((i) => i.id !== id)),
  };
}

export function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}
