import { Link, useRouterState } from "@tanstack/react-router";
import { type ReactNode } from "react";
import logo from "@/assets/kzt-logo.png.asset.json";

const NAV = [
  { to: "/", label: "Home" },
  { to: "/portfolio", label: "Portfolio" },
  { to: "/contact", label: "Contact" },
  { to: "/admin", label: "Upload" },
] as const;

export const WHATSAPP = "923183100770"; // +92 318 3100 770
export const WHATSAPP_DISPLAY = "+92 318 3100 770";
export const INSTAGRAM = "https://www.instagram.com/kzt_visual?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw%3D%3D";
export const INSTAGRAM_HANDLE = "@kzt_visual";

export function SiteShell({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground">
      <header className="sticky top-0 z-40 border-b border-border bg-background/85 backdrop-blur">
        <div className="container-page flex items-center justify-between h-16">
          <Link to="/" className="flex items-center gap-2.5 group">
            <span className="inline-flex h-9 w-9 items-center justify-center rounded-md bg-ink overflow-hidden">
              <img src={logo.url} alt="KZT" className="h-7 w-7 object-contain" />
            </span>
            <span className="flex flex-col leading-none">
              <span className="font-display text-lg tracking-tight">KZT Visual</span>
              <span className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground">Creative Agency · PK</span>
            </span>
          </Link>
          <nav className="hidden md:flex items-center gap-1">
            {NAV.map((n) => {
              const active = pathname === n.to;
              return (
                <Link
                  key={n.to}
                  to={n.to}
                  className={`px-3 py-2 text-sm transition-colors ${
                    active ? "text-foreground" : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  {n.label}
                  {active && <span className="block h-px bg-accent mt-1" />}
                </Link>
              );
            })}
          </nav>
          <a
            href={`https://wa.me/${WHATSAPP}`}
            target="_blank"
            rel="noreferrer"
            className="hidden sm:inline-flex items-center gap-2 rounded-full bg-ink text-primary-foreground px-4 py-2 text-sm hover:bg-foreground transition-colors"
          >
            <WhatsappIcon className="h-4 w-4" />
            Start a project
          </a>
        </div>
        <div className="md:hidden border-t border-border">
          <div className="container-page flex gap-4 overflow-x-auto py-2 text-sm">
            {NAV.map((n) => {
              const active = pathname === n.to;
              return (
                <Link
                  key={n.to}
                  to={n.to}
                  className={active ? "text-foreground" : "text-muted-foreground"}
                >
                  {n.label}
                </Link>
              );
            })}
          </div>
        </div>
      </header>

      <main className="flex-1">{children}</main>

      <footer className="border-t border-border mt-24">
        <div className="container-page py-12 grid gap-10 md:grid-cols-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="inline-flex h-8 w-8 items-center justify-center rounded-md bg-ink overflow-hidden">
                <img src={logo.url} alt="KZT" className="h-6 w-6 object-contain" />
              </span>
              <span className="font-display text-lg">KZT Visual</span>
            </div>
            <p className="mt-3 text-sm text-muted-foreground max-w-xs">
              A Pakistani creative studio by Zoxi, Kentor & talal. Design, edit, score, write.
            </p>
          </div>
          <div className="text-sm">
            <div className="uppercase tracking-[0.18em] text-xs text-muted-foreground mb-3">Studio</div>
            <ul className="space-y-1.5">
              <li><Link to="/portfolio" className="hover:text-accent">Portfolio</Link></li>
              <li><Link to="/contact" className="hover:text-accent">Contact</Link></li>
              <li><a href={INSTAGRAM} target="_blank" rel="noreferrer" className="hover:text-accent">Instagram</a></li>
            </ul>
          </div>
          <div className="text-sm">
            <div className="uppercase tracking-[0.18em] text-xs text-muted-foreground mb-3">Reach us</div>
            <ul className="space-y-1.5">
              <li><a className="hover:text-accent" href={`https://wa.me/${WHATSAPP}`} target="_blank" rel="noreferrer">WhatsApp · {WHATSAPP_DISPLAY}</a></li>
              <li><a className="hover:text-accent" href={INSTAGRAM} target="_blank" rel="noreferrer">Instagram · {INSTAGRAM_HANDLE}</a></li>
            </ul>
          </div>
        </div>
        <div className="border-t border-border">
          <div className="container-page py-5 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-muted-foreground">
            <span>© {new Date().getFullYear()} KZT Visual. All rights reserved.</span>
            <span>Made in Pakistan 🇵🇰</span>
          </div>
        </div>
      </footer>

      <a
        href={`https://wa.me/${WHATSAPP}?text=${encodeURIComponent("Hi KZT Visual, I'd like to start a project.")}`}
        target="_blank"
        rel="noreferrer"
        aria-label="Chat on WhatsApp"
        className="fixed bottom-5 right-5 z-50 inline-flex items-center gap-2 rounded-full bg-accent text-accent-foreground px-4 py-3 shadow-lg shadow-accent/30 hover:translate-y-[-2px] transition-transform"
      >
        <WhatsappIcon className="h-5 w-5" />
        <span className="text-sm font-medium hidden sm:inline">WhatsApp us</span>
      </a>
    </div>
  );
}

export function WhatsappIcon({ className = "h-5 w-5" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden>
      <path d="M19.11 4.91A10 10 0 0 0 2.05 15.5L1 21l5.62-1.47A10 10 0 1 0 19.11 4.91Zm-7.1 15.36a8.34 8.34 0 0 1-4.25-1.16l-.31-.18-3.34.87.89-3.25-.2-.33a8.36 8.36 0 1 1 7.21 4.05Zm4.59-6.26c-.25-.13-1.49-.74-1.72-.82s-.4-.13-.57.13-.66.82-.81.99-.3.19-.55.06a6.86 6.86 0 0 1-2.02-1.25 7.6 7.6 0 0 1-1.4-1.74c-.15-.25 0-.38.11-.5s.25-.3.37-.45a1.75 1.75 0 0 0 .25-.41.45.45 0 0 0 0-.44c-.06-.13-.57-1.38-.78-1.88s-.41-.43-.57-.43h-.49a.94.94 0 0 0-.68.32 2.86 2.86 0 0 0-.9 2.13 5 5 0 0 0 1.05 2.66 11.45 11.45 0 0 0 4.39 3.86c.61.27 1.09.43 1.46.55a3.53 3.53 0 0 0 1.61.1 2.63 2.63 0 0 0 1.72-1.21 2.13 2.13 0 0 0 .15-1.21c-.06-.1-.23-.17-.48-.3Z" />
    </svg>
  );
}

export function InstagramIcon({ className = "h-5 w-5" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className={className} aria-hidden>
      <rect x="3" y="3" width="18" height="18" rx="5" />
      <circle cx="12" cy="12" r="4" />
      <circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none" />
    </svg>
  );
}
