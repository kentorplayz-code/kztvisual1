import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { SiteShell, WHATSAPP, WHATSAPP_DISPLAY, INSTAGRAM, INSTAGRAM_HANDLE, WhatsappIcon, InstagramIcon } from "@/components/site-shell";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact — KZT Visual" },
      { name: "description", content: "Get in touch with KZT Visual on WhatsApp or Instagram." },
      { property: "og:title", content: "Contact — KZT Visual" },
      { property: "og:description", content: "Reach the KZT Visual studio." },
    ],
  }),
  component: ContactPage,
});

function ContactPage() {
  const [name, setName] = useState("");
  const [service, setService] = useState("Graphic Design");
  const [message, setMessage] = useState("");

  const text = encodeURIComponent(
    `Hi KZT Visual!\n\nName: ${name || "—"}\nService: ${service}\n\n${message || ""}`
  );

  return (
    <SiteShell>
      <section className="container-page pt-16 pb-12">
        <div className="text-xs uppercase tracking-[0.2em] text-muted-foreground">Contact</div>
        <h1 className="mt-3 font-display text-5xl md:text-7xl leading-[0.95] tracking-tight">
          Let's <span className="italic text-accent">talk</span>.
        </h1>
        <p className="mt-5 max-w-xl text-muted-foreground">
          Drop the studio a message on WhatsApp or DM us on Instagram. We usually reply within a few hours.
        </p>
      </section>

      <section className="container-page pb-24 grid lg:grid-cols-5 gap-8">
        {/* Form */}
        <div className="lg:col-span-3 rounded-2xl border border-border bg-card p-6 md:p-8">
          <h2 className="font-display text-2xl">Send a brief</h2>
          <p className="text-sm text-muted-foreground mt-1">This opens WhatsApp with your message pre-filled.</p>

          <div className="mt-6 grid gap-4">
            <label className="grid gap-1.5 text-sm">
              <span className="text-muted-foreground">Your name</span>
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="rounded-lg border border-border bg-background px-3 py-2.5 focus:outline-none focus:border-accent"
                placeholder="e.g. Ali Raza"
              />
            </label>

            <label className="grid gap-1.5 text-sm">
              <span className="text-muted-foreground">What do you need?</span>
              <select
                value={service}
                onChange={(e) => setService(e.target.value)}
                className="rounded-lg border border-border bg-background px-3 py-2.5 focus:outline-none focus:border-accent"
              >
                <option>Graphic Design</option>
                <option>Video Editing</option>
                <option>Beat Making</option>
                <option>Script Writing</option>
                <option>Full Brand Package</option>
              </select>
            </label>

            <label className="grid gap-1.5 text-sm">
              <span className="text-muted-foreground">Tell us about the project</span>
              <textarea
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                rows={5}
                className="rounded-lg border border-border bg-background px-3 py-2.5 focus:outline-none focus:border-accent resize-none"
                placeholder="Goals, deadlines, references..."
              />
            </label>

            <a
              href={`https://wa.me/${WHATSAPP}?text=${text}`}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center justify-center gap-2 rounded-full bg-accent text-accent-foreground px-5 py-3 text-sm hover:opacity-90"
            >
              <WhatsappIcon className="h-4 w-4" />
              Send on WhatsApp
            </a>
          </div>
        </div>

        {/* Sidebar */}
        <div className="lg:col-span-2 space-y-4">
          <a
            href={`https://wa.me/${WHATSAPP}`}
            target="_blank"
            rel="noreferrer"
            className="block rounded-2xl border border-border bg-card p-6 hover:border-accent transition-colors"
          >
            <div className="flex items-center gap-3">
              <span className="inline-flex h-10 w-10 items-center justify-center rounded-full bg-accent text-accent-foreground">
                <WhatsappIcon className="h-5 w-5" />
              </span>
              <div>
                <div className="text-xs uppercase tracking-[0.18em] text-muted-foreground">WhatsApp</div>
                <div className="font-display text-xl">{WHATSAPP_DISPLAY}</div>
              </div>
            </div>
            <p className="text-sm text-muted-foreground mt-4">Fastest way to reach us. Tap to start a chat.</p>
          </a>

          <a
            href={INSTAGRAM}
            target="_blank"
            rel="noreferrer"
            className="block rounded-2xl border border-border bg-card p-6 hover:border-accent transition-colors"
          >
            <div className="flex items-center gap-3">
              <span className="inline-flex h-10 w-10 items-center justify-center rounded-full bg-ink text-primary-foreground">
                <InstagramIcon className="h-5 w-5" />
              </span>
              <div>
                <div className="text-xs uppercase tracking-[0.18em] text-muted-foreground">Instagram</div>
                <div className="font-display text-xl">{INSTAGRAM_HANDLE}</div>
              </div>
            </div>
            <p className="text-sm text-muted-foreground mt-4">See the latest reels, drops and behind-the-scenes.</p>
          </a>

          <div className="rounded-2xl border border-border bg-ink text-primary-foreground p-6">
            <div className="text-xs uppercase tracking-[0.18em] text-white/60">Studio</div>
            <div className="font-display text-xl mt-1">KZT Visual</div>
            <p className="text-sm text-white/70 mt-2">Based in Pakistan. Working with clients worldwide.</p>
          </div>
        </div>
      </section>
    </SiteShell>
  );
}
