import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { SiteShell } from "@/components/site-shell";
import { CATEGORIES, fileToDataUrl, usePortfolio, type Category } from "@/lib/portfolio-store";

export const Route = createFileRoute("/admin")({
  head: () => ({
    meta: [
      { title: "Upload — KZT Visual" },
      { name: "description", content: "Upload portfolio pieces (thumbnail + voice) to the KZT Visual portfolio." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AdminGate,
});

const ADMIN_KEY = "kzt_admin_unlock_v1";
const ADMIN_PASSCODE = "kzt-2026";

function AdminGate() {
  const [unlocked, setUnlocked] = useState(false);
  const [pass, setPass] = useState("");
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    if (typeof window !== "undefined" && localStorage.getItem(ADMIN_KEY) === "1") {
      setUnlocked(true);
    }
  }, []);

  if (unlocked) return <AdminPage onLock={() => { localStorage.removeItem(ADMIN_KEY); setUnlocked(false); }} />;

  return (
    <SiteShell>
      <section className="container-page pt-24 pb-24 max-w-md">
        <div className="text-xs uppercase tracking-[0.2em] text-muted-foreground">Studio · Restricted</div>
        <h1 className="mt-3 font-display text-4xl leading-[0.95]">
          Owners <span className="italic text-accent">only</span>.
        </h1>
        <p className="mt-3 text-sm text-muted-foreground">Enter the studio passcode to upload work.</p>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (pass === ADMIN_PASSCODE) {
              localStorage.setItem(ADMIN_KEY, "1");
              setUnlocked(true);
            } else {
              setErr("Wrong passcode.");
            }
          }}
          className="mt-6 space-y-3"
        >
          <input
            type="password"
            value={pass}
            onChange={(e) => { setPass(e.target.value); setErr(null); }}
            placeholder="Passcode"
            className="w-full rounded-lg border border-border bg-background px-3 py-2.5 focus:outline-none focus:border-accent"
            autoFocus
          />
          {err && <div className="text-sm text-destructive">{err}</div>}
          <button type="submit" className="inline-flex items-center justify-center gap-2 rounded-full bg-accent text-accent-foreground px-5 py-3 text-sm hover:opacity-90">
            Unlock studio
          </button>
        </form>
      </section>
    </SiteShell>
  );
}

function AdminPage({ onLock }: { onLock: () => void }) {
  const { items, add, remove } = usePortfolio();
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState<Category>("graphic-design");
  const [thumbFile, setThumbFile] = useState<File | null>(null);
  const [audioFile, setAudioFile] = useState<File | null>(null);
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setErr(null);
    if (!title.trim()) return setErr("Add a title.");
    if (!thumbFile) return setErr("Upload a video thumbnail image.");
    setBusy(true);
    try {
      const thumbnail = await fileToDataUrl(thumbFile);
      const audio = audioFile ? await fileToDataUrl(audioFile) : undefined;
      const video = videoFile ? await fileToDataUrl(videoFile) : undefined;
      add({ title: title.trim(), category, thumbnail, audio, video });
      setTitle("");
      setThumbFile(null);
      setAudioFile(null);
      setVideoFile(null);
      ["thumb-input", "audio-input", "video-input"].forEach((id) => {
        const el = document.getElementById(id) as HTMLInputElement | null;
        if (el) el.value = "";
      });
    } catch (e) {
      setErr("Something went wrong. Try a smaller file.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <SiteShell>
      <section className="container-page pt-16 pb-10">
        <div className="text-xs uppercase tracking-[0.2em] text-muted-foreground">Studio · Upload</div>
        <h1 className="mt-3 font-display text-5xl md:text-6xl leading-[0.95]">
          Add a <span className="italic text-accent">piece</span>.
        </h1>
        <p className="mt-4 max-w-xl text-muted-foreground">
          Upload a video thumbnail and (optional) voice/audio. It'll appear instantly on the portfolio.
        </p>
        <button onClick={onLock} className="mt-4 text-xs uppercase tracking-[0.2em] text-muted-foreground hover:text-accent">Lock studio →</button>
      </section>

      <section className="container-page pb-24 grid lg:grid-cols-2 gap-8">
        <form onSubmit={submit} className="rounded-2xl border border-border bg-card p-6 md:p-8 space-y-5">
          <label className="grid gap-1.5 text-sm">
            <span className="text-muted-foreground">Title</span>
            <input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="rounded-lg border border-border bg-background px-3 py-2.5 focus:outline-none focus:border-accent"
              placeholder="e.g. Nova Soda · Launch Reel"
            />
          </label>

          <label className="grid gap-1.5 text-sm">
            <span className="text-muted-foreground">Category</span>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value as Category)}
              className="rounded-lg border border-border bg-background px-3 py-2.5 focus:outline-none focus:border-accent"
            >
              {CATEGORIES.map((c) => (
                <option key={c.id} value={c.id}>{c.label}</option>
              ))}
            </select>
          </label>

          <label className="grid gap-1.5 text-sm">
            <span className="text-muted-foreground">Video thumbnail (image)</span>
            <input
              id="thumb-input"
              type="file"
              accept="image/*"
              onChange={(e) => setThumbFile(e.target.files?.[0] ?? null)}
              className="rounded-lg border border-dashed border-border bg-background px-3 py-2.5 file:mr-3 file:rounded-md file:border-0 file:bg-ink file:text-primary-foreground file:px-3 file:py-1.5 file:text-xs"
            />
          </label>

          <label className="grid gap-1.5 text-sm">
            <span className="text-muted-foreground">Voice / audio (optional)</span>
            <input
              id="audio-input"
              type="file"
              accept="audio/*"
              onChange={(e) => setAudioFile(e.target.files?.[0] ?? null)}
              className="rounded-lg border border-dashed border-border bg-background px-3 py-2.5 file:mr-3 file:rounded-md file:border-0 file:bg-ink file:text-primary-foreground file:px-3 file:py-1.5 file:text-xs"
            />
          </label>

          <label className="grid gap-1.5 text-sm">
            <span className="text-muted-foreground">Video (optional)</span>
            <input
              id="video-input"
              type="file"
              accept="video/*"
              onChange={(e) => setVideoFile(e.target.files?.[0] ?? null)}
              className="rounded-lg border border-dashed border-border bg-background px-3 py-2.5 file:mr-3 file:rounded-md file:border-0 file:bg-ink file:text-primary-foreground file:px-3 file:py-1.5 file:text-xs"
            />
          </label>

          {err && <div className="text-sm text-destructive">{err}</div>}

          <button
            type="submit"
            disabled={busy}
            className="inline-flex items-center justify-center gap-2 rounded-full bg-accent text-accent-foreground px-5 py-3 text-sm hover:opacity-90 disabled:opacity-60"
          >
            {busy ? "Uploading…" : "Add to portfolio"}
          </button>
          <p className="text-xs text-muted-foreground">Files are stored locally in your browser. Use small files (under ~5 MB) for best performance — large videos may fail to save.</p>
        </form>

        <div>
          <div className="text-xs uppercase tracking-[0.2em] text-muted-foreground mb-3">Uploaded ({items.length})</div>
          <div className="space-y-3 max-h-[600px] overflow-y-auto pr-1">
            {items.length === 0 && (
              <div className="rounded-xl border border-dashed border-border p-6 text-sm text-muted-foreground">Nothing uploaded yet.</div>
            )}
            {items.map((it) => (
              <div key={it.id} className="flex gap-3 rounded-xl border border-border bg-card p-3">
                <img src={it.thumbnail} alt={it.title} className="h-20 w-28 rounded-md object-cover bg-secondary" />
                <div className="flex-1 min-w-0">
                  <div className="text-[11px] uppercase tracking-[0.18em] text-accent">
                    {CATEGORIES.find((c) => c.id === it.category)?.label}
                  </div>
                  <div className="font-display text-base truncate">{it.title}</div>
                  {it.audio && <audio controls src={it.audio} className="mt-1 w-full h-8" />}
                  {it.video && <span className="mt-1 inline-block text-[10px] uppercase tracking-[0.18em] text-muted-foreground">▶ Video attached</span>}
                </div>
                <button
                  onClick={() => remove(it.id)}
                  className="self-start text-xs text-muted-foreground hover:text-destructive"
                >
                  Remove
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>
    </SiteShell>
  );
}
