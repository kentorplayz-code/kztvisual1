import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteShell, WHATSAPP, WHATSAPP_DISPLAY, INSTAGRAM, INSTAGRAM_HANDLE, WhatsappIcon, InstagramIcon } from "@/components/site-shell";
import { CATEGORIES, usePortfolio } from "@/lib/portfolio-store";
import logo from "@/assets/kzt-logo.png.asset.json";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "KZT Visual — Pakistan's Creative Agency" },
      { name: "description", content: "KZT Visual is a Pakistani creative agency by Zoxi, Kentor & talal. Graphic design, video editing, beat making, script writing." },
      { property: "og:title", content: "KZT Visual — Pakistan's Creative Agency" },
      { property: "og:description", content: "Design, edit, score, write. The best creative studio out of Pakistan." },
    ],
  }),
  component: Home,
});

function Home() {
  const { items } = usePortfolio();
  const founders = ["Zoxi", "Kentor", "talal"];

  return (
    <SiteShell>
      {/* HERO */}
      <section className="relative overflow-hidden">
        <div className="container-page pt-16 pb-20 md:pt-24 md:pb-28 grid lg:grid-cols-12 gap-10 items-end">
          <div className="lg:col-span-8">
            <div className="inline-flex items-center gap-2 rounded-full border border-border bg-secondary px-3 py-1 text-xs uppercase tracking-[0.18em] text-muted-foreground">
              <span className="h-1.5 w-1.5 rounded-full bg-accent" />
              Pakistan · Est. by Zoxi, Kentor & talal
            </div>
            <h1 className="mt-6 font-display text-[clamp(2.5rem,7vw,5.75rem)] leading-[0.95] tracking-tight text-balance">
              We make brands <span className="italic text-accent">look</span>,
              <br /> sound &amp; speak{" "}
              <span className="relative inline-block">
                louder.
                <span className="absolute inset-x-0 -bottom-1 h-2 bg-accent/30" />
              </span>
            </h1>
            <p className="mt-6 max-w-xl text-base md:text-lg text-muted-foreground">
              KZT Visual is a Pakistani creative agency crafting graphic design, video edits, beats and scripts that actually move the needle.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link
                to="/portfolio"
                className="inline-flex items-center gap-2 rounded-full bg-ink text-primary-foreground px-5 py-3 text-sm hover:bg-foreground transition"
              >
                See the work
                <span aria-hidden>↗</span>
              </Link>
              <a
                href={`https://wa.me/${WHATSAPP}?text=${encodeURIComponent("Hi KZT Visual, I'd like to start a project.")}`}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-2 rounded-full border border-border bg-background px-5 py-3 text-sm hover:border-accent hover:text-accent transition"
              >
                <WhatsappIcon className="h-4 w-4" />
                Chat on WhatsApp
              </a>
            </div>
          </div>

          <div className="lg:col-span-4 relative">
            <div className="aspect-square rounded-2xl bg-ink relative overflow-hidden shadow-xl">
              <img src={logo.url} alt="KZT Visual logo" className="absolute inset-0 m-auto h-[92%] w-[92%] object-contain scale-110" />
              <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between text-[10px] uppercase tracking-[0.2em] text-white/60">
                <span>KZT · 001</span>
                <span>Visual Studio</span>
              </div>
            </div>
            <div className="absolute -bottom-4 -left-4 hidden md:flex items-center gap-2 rounded-full bg-accent text-accent-foreground px-3 py-1.5 text-xs font-medium shadow-md">
              ● Booking June – August
            </div>
          </div>
        </div>

        {/* Marquee */}
        <div className="border-y border-border bg-secondary/60 overflow-hidden">
          <div className="flex marquee-track whitespace-nowrap py-4 text-sm uppercase tracking-[0.3em] text-muted-foreground">
            {Array.from({ length: 2 }).map((_, i) => (
              <div key={i} className="flex items-center gap-10 px-5 shrink-0">
                {["Graphic Design", "Video Editing", "Beat Making", "Script Writing", "Brand Systems", "Reels & Shorts", "Sound Design"].map((s) => (
                  <span key={s} className="flex items-center gap-10">
                    <span>{s}</span>
                    <span className="text-accent">✦</span>
                  </span>
                ))}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* WHO */}
      <section className="container-page py-20 grid lg:grid-cols-12 gap-10">
        <div className="lg:col-span-5">
          <div className="text-xs uppercase tracking-[0.2em] text-muted-foreground">Who we are</div>
          <h2 className="mt-3 font-display text-4xl md:text-5xl leading-tight">
            A three-person studio out of Pakistan, building work that punches above its weight.
          </h2>
        </div>
        <div className="lg:col-span-7 grid sm:grid-cols-3 gap-4">
          {founders.map((name, idx) => (
            <div
              key={name}
              className="group relative rounded-xl border border-border bg-card p-6 hover:border-accent transition-colors"
            >
              <div className="text-[11px] uppercase tracking-[0.2em] text-muted-foreground">Founder · 0{idx + 1}</div>
              <div className="mt-10 font-display text-3xl">{name}</div>
              <div className="mt-1 text-sm text-muted-foreground">
                {idx === 0 && "Design & direction"}
                {idx === 1 && "Video & motion"}
                {idx === 2 && "Sound & scripts"}
              </div>
              <div className="absolute top-6 right-6 h-2 w-2 rounded-full bg-accent group-hover:scale-150 transition-transform" />
            </div>
          ))}
        </div>
      </section>

      {/* SERVICES */}
      <section className="border-y border-border bg-secondary/40">
        <div className="container-page py-20">
          <div className="flex items-end justify-between flex-wrap gap-4">
            <div>
              <div className="text-xs uppercase tracking-[0.2em] text-muted-foreground">What we do</div>
              <h2 className="mt-3 font-display text-4xl md:text-5xl">Four crafts. One studio.</h2>
            </div>
            <Link to="/portfolio" className="text-sm underline underline-offset-4 hover:text-accent">View portfolio →</Link>
          </div>

          <div className="mt-10 grid sm:grid-cols-2 lg:grid-cols-4 gap-px bg-border rounded-xl overflow-hidden border border-border">
            {CATEGORIES.map((c, i) => (
              <div key={c.id} className="bg-background p-6 min-h-[220px] flex flex-col justify-between hover:bg-card transition-colors">
                <div className="text-xs text-muted-foreground">0{i + 1} / 04</div>
                <div>
                  <div className="font-display text-2xl">{c.label}</div>
                  <p className="mt-2 text-sm text-muted-foreground">{c.blurb}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* RECENT WORK */}
      <section className="container-page py-20">
        <div className="flex items-end justify-between flex-wrap gap-4">
          <div>
            <div className="text-xs uppercase tracking-[0.2em] text-muted-foreground">Recent</div>
            <h2 className="mt-3 font-display text-4xl md:text-5xl">Latest from the studio</h2>
          </div>
          <Link to="/portfolio" className="text-sm underline underline-offset-4 hover:text-accent">All work →</Link>
        </div>

        {items.length === 0 ? (
          <div className="mt-10 rounded-xl border border-dashed border-border p-10 text-center text-muted-foreground">
            <p>No portfolio pieces yet.</p>
            <Link to="/admin" className="inline-block mt-3 text-accent underline underline-offset-4">Upload your first piece →</Link>
          </div>
        ) : (
          <div className="mt-10 grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {items.slice(0, 6).map((it) => (
              <div key={it.id} className="group rounded-xl overflow-hidden border border-border bg-card">
                <div className="aspect-video bg-secondary overflow-hidden">
                  {it.video ? (
                    <video src={it.video} poster={it.thumbnail} controls preload="metadata" className="h-full w-full object-cover" />
                  ) : (
                    <img src={it.thumbnail} alt={it.title} className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-500" />
                  )}
                </div>
                <div className="p-4">
                  <div className="text-[11px] uppercase tracking-[0.18em] text-accent">
                    {CATEGORIES.find((c) => c.id === it.category)?.label}
                  </div>
                  <div className="mt-1 font-display text-lg">{it.title}</div>
                  {it.audio && <audio controls src={it.audio} className="mt-3 w-full" />}
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* CTA */}
      <section className="container-page pb-24">
        <div className="rounded-3xl bg-ink text-primary-foreground p-10 md:p-16 grid lg:grid-cols-2 gap-10 items-center relative overflow-hidden">
          <div className="absolute -right-20 -top-20 h-72 w-72 rounded-full bg-accent/30 blur-3xl" />
          <div>
            <h2 className="font-display text-4xl md:text-5xl leading-tight">Got a brief?<br />Let's make something loud.</h2>
            <p className="mt-4 text-white/70 max-w-md">Tell us about your brand, project, or idea. We reply on WhatsApp within hours.</p>
          </div>
          <div className="flex flex-wrap gap-3 lg:justify-end">
            <a href={`https://wa.me/${WHATSAPP}?text=${encodeURIComponent("Hi KZT Visual!")}`} target="_blank" rel="noreferrer"
              className="inline-flex items-center gap-2 rounded-full bg-accent text-accent-foreground px-5 py-3 text-sm hover:opacity-90">
              <WhatsappIcon className="h-4 w-4" /> WhatsApp · {WHATSAPP_DISPLAY}
            </a>
            <a href={INSTAGRAM} target="_blank" rel="noreferrer"
              className="inline-flex items-center gap-2 rounded-full border border-white/20 px-5 py-3 text-sm hover:bg-white/10">
              <InstagramIcon className="h-4 w-4" /> {INSTAGRAM_HANDLE}
            </a>
          </div>
        </div>
      </section>
    </SiteShell>
  );
}
