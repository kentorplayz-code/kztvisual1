import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { SiteShell } from "@/components/site-shell";
import { CATEGORIES, usePortfolio, type Category } from "@/lib/portfolio-store";

export const Route = createFileRoute("/portfolio")({
  head: () => ({
    meta: [
      { title: "Portfolio — KZT Visual" },
      { name: "description", content: "Selected work by KZT Visual across graphic design, video editing, beat making and script writing." },
      { property: "og:title", content: "Portfolio — KZT Visual" },
      { property: "og:description", content: "Selected work across design, video, music and writing." },
    ],
  }),
  component: PortfolioPage,
});

function PortfolioPage() {
  const { items } = usePortfolio();
  const [active, setActive] = useState<Category | "all">("all");

  const filtered = active === "all" ? items : items.filter((i) => i.category === active);

  return (
    <SiteShell>
      <section className="container-page pt-16 pb-10">
        <div className="text-xs uppercase tracking-[0.2em] text-muted-foreground">Portfolio</div>
        <h1 className="mt-3 font-display text-5xl md:text-7xl leading-[0.95] tracking-tight">
          Selected <span className="italic text-accent">work</span>.
        </h1>
        <p className="mt-5 max-w-xl text-muted-foreground">
          A living archive of projects from KZT Visual — filter by craft.
        </p>
      </section>

      <section className="container-page">
        <div className="flex flex-wrap gap-2 border-b border-border pb-4">
          {([{ id: "all", label: `All (${items.length})` }, ...CATEGORIES.map((c) => ({ id: c.id, label: c.label }))] as const).map((tab) => {
            const isActive = active === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActive(tab.id as Category | "all")}
                className={`rounded-full px-4 py-2 text-sm transition-colors border ${
                  isActive
                    ? "bg-ink text-primary-foreground border-ink"
                    : "border-border text-muted-foreground hover:text-foreground hover:border-foreground"
                }`}
              >
                {tab.label}
              </button>
            );
          })}
        </div>
      </section>

      <section className="container-page py-12">
        {filtered.length === 0 ? (
          <div className="rounded-xl border border-dashed border-border p-16 text-center text-muted-foreground">
            <p className="font-display text-2xl text-foreground">Nothing here yet</p>
            <p className="mt-2">Pieces uploaded from the studio will appear in this section.</p>
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filtered.map((it) => (
              <article key={it.id} className="group rounded-xl overflow-hidden border border-border bg-card">
                <div className="aspect-video bg-secondary overflow-hidden">
                  {it.video ? (
                    <video src={it.video} poster={it.thumbnail} controls preload="metadata" className="h-full w-full object-cover" />
                  ) : (
                    <img src={it.thumbnail} alt={it.title} className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-500" />
                  )}
                </div>
                <div className="p-5">
                  <div className="text-[11px] uppercase tracking-[0.18em] text-accent">
                    {CATEGORIES.find((c) => c.id === it.category)?.label}
                  </div>
                  <h3 className="mt-1 font-display text-xl">{it.title}</h3>
                  {it.audio && <audio controls src={it.audio} className="mt-4 w-full" />}
                </div>
              </article>
            ))}
          </div>
        )}
      </section>
    </SiteShell>
  );
}
